<?php
include 'model_pasien.php';
$isiTabelPasien = getTablePasien();
include 'view_pasien.php';
?>